#ifndef _LAMBERTIAN_H_
#define _LAMBERTIAN_H_

#include "Material.h"
#include "Defines.h"
#include "Ray.h"
#include "Texture.h"
#include "ONB.h"
namespace RTX {
	using namespace CppUtil::Basic;
	class Lambertian : public Material {
	public:
		Lambertian(const vec3& a) : albedo(ToPtr(new SolidColor(a))) {}
		Lambertian(CppUtil::Basic::Ptr<Texture> a) : albedo(a) {}

		virtual bool scatter(CppUtil::Basic::Ptr<Ray> ray, const Hit_record& rec,
			scatter_record& srec) const override {
			srec.attenuation = albedo->value(rec.uv, rec.p);
			srec.pdf_ptr = ToPtr(new CosinePDF(rec.normal));
			return true;
		}

		virtual float scattering_pdf(CppUtil::Basic::Ptr<Ray> ray, const Hit_record& rec,
			CppUtil::Basic::Ptr<Ray>& scattered) const {
			auto cosine = dot(rec.normal, normalize(scattered->direction()));
			return cosine < 0 ? 0 : cosine / pi;
		}
	protected:
		CppUtil::Basic::Ptr <Texture> albedo;
	};
}

#endif // !_LAMBERTIAN_H_
