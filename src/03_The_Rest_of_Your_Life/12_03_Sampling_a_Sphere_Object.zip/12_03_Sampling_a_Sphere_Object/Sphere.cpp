#include <CppUtil/Basic/Math.h>

#include "Sphere.h"
#include "Ray.h"
#include "Defines.h"
#include "ONB.h"

using namespace RTX;
using namespace CppUtil::Basic;
using namespace glm;
using namespace Define;

Sphere::Sphere(const vec3 & center, float radius, CppUtil::Basic::Ptr<Material> material)
	: center(center), radius(radius), material(material){}

bool Sphere::hit(CppUtil::Basic::Ptr<Ray> ray, float t_min, float t_max, Hit_record& rec) const
{
	vec3 oc = ray->origin() - center;
	auto dir = ray->direction();
	auto a = dot(dir, dir);
	auto half_b = dot(oc, dir);
	auto c = dot(oc, oc) - radius * radius;
	auto discriminant = half_b * half_b - a * c;

	if (discriminant > 0) {
		auto root = sqrt(discriminant);

		auto temp = (-half_b - root) / a;
		if (temp < t_max && temp > t_min) {
			rec.t = temp;
			rec.p = ray->at(rec.t);
			rec.set_face_normal(ray, (rec.p - center) / radius);
			Define::get_sphere_uv((rec.p - center) / radius, rec.uv);
			rec.material = material;
			return true;
		}

		temp = (-half_b + root) / a;
		if (temp < t_max && temp > t_min) {
			rec.t = temp;
			rec.p = ray->at(rec.t);
			rec.set_face_normal(ray, (rec.p - center) / radius);
			Define::get_sphere_uv((rec.p - center) / radius, rec.uv);
			rec.material = material;
			return true;
		}
	}
	return false;
}

bool Sphere::boundingBox(float t0, float t1, AABB& output_box) const
{
    output_box = AABB(center - vec3(radius), center + vec3(radius));
    return true;
}

float Sphere::pdfValue(const vec3& origin, const vec3& v) const 
{
	Hit_record rec;
	
	if (!this->hit(ToPtr(new Ray(origin, v)), 0.001f, infinity, rec))
		return 0.0f;

	auto cos_theta_max = sqrt(1 - radius * radius / length_2(center - origin));
	auto solid_angle = pi * (1.0f - cos_theta_max);
	//�����2 * pi -> pi
	return 0.5f / solid_angle;
}

vec3 Sphere::random(const vec3& origin) const
{
	return vec3(1.0f, 0.0f, 0.0f);
	vec3 direction = center - origin;
	auto distance_squared = length_2(direction);
	ONB uvw;
	uvw.build_from_w(direction);
	return uvw.local(random_to_sphere(radius, distance_squared));
}