#ifndef _MATERIAL_H_
#define _MATERIAL_H_

#include <CppUtil/Basic/HeapObj.h>
#include <glm/glm.hpp>
#include <vector>

#include "Ray.h"
#include "Hitable.h"
#include "PDF.h"

namespace RTX {
	struct scatter_record {
		CppUtil::Basic::Ptr<Ray> specular_ray = nullptr;
		bool is_specular = false;
		rgb attenuation = rgb(0.0f);
		CppUtil::Basic::Ptr<PDF> pdf_ptr = nullptr;
	};

	class Material : public CppUtil::Basic::HeapObj{
		HEAP_OBJ_SETUP(Material)
	public:
		// ����ֵΪ true ˵�����߼�������
		// ����ֵΪ false ˵�����߲��ٴ���
		Hit_record r;
		virtual rgb emitted(CppUtil::Basic::Ptr<Ray> ray, const Hit_record& rec,
			const vec2& uv, const vec3& p) const { return rgb(0.0f); }

		virtual bool scatter(CppUtil::Basic::Ptr<Ray> ray, const Hit_record& rec,
			scatter_record& srec) const{ return false; }

		virtual float scattering_pdf(CppUtil::Basic::Ptr<Ray> ray, const Hit_record& rec,
			CppUtil::Basic::Ptr<Ray>& scattered) const { return 0; }
	};
}

#endif // !_MATERIAL_H_
